//
//  TBooleanLiteral.cpp
//  DainaCompiler
//
//  Created by SamWit on 22/12/2016.
//  Copyright © 2016 Samuel Whitton. All rights reserved.
//

#include "TBooleanLiteral.hpp"
