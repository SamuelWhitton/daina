//
//  TIntegerLiteral.hpp
//  DainaCompiler
//
//  Created by SamWit on 21/12/2016.
//  Copyright © 2016 Samuel Whitton. All rights reserved.
//

#ifndef TIntegerLiteral_hpp
#define TIntegerLiteral_hpp

#include "Token.hpp"

namespace Daina {
    
    /*class TIntegerLiteral : public Token {
    public:
        TIntegerLiteral(SourceChar start, std::string strInteger) : Token(tIntegerLiteral, start), strInteger(strInteger) {};
        virtual std::string getInCodeIdentificationString() {
            return strInteger + Token::getInCodeIdentificationString();
        }


	std::string zitherLiteralRepresentation() {
	    return strInteger;
	}
        
        std::string strInteger;
    };*/
    
}


#endif /* TIntegerLiteral_hpp */
