//
//  TIntegerLiteral.cpp
//  DainaCompiler
//
//  Created by SamWit on 21/12/2016.
//  Copyright © 2016 Samuel Whitton. All rights reserved.
//

#include "TIntegerLiteral.hpp"
