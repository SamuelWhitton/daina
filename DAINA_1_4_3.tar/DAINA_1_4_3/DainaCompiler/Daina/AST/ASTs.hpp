//
//  ASTs.h
//  DainaCompiler
//
//  Created by SamWit on 6/01/2017.
//  Copyright © 2017 Samuel Whitton. All rights reserved.
//

#ifndef ASTs_h
#define ASTs_h

#include "AST.hpp"
#include "ASTRoot.hpp"


#endif /* ASTs_h */
