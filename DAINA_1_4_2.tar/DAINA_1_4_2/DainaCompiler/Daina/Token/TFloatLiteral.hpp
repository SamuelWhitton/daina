//
//  TFloatLiteral.hpp
//  DainaCompiler
//
//  Created by SamWit on 21/12/2016.
//  Copyright © 2016 Samuel Whitton. All rights reserved.
//

#ifndef TFloatLiteral_hpp
#define TFloatLiteral_hpp

#include "Token.hpp"

namespace Daina {
    
    /*class TFloatLiteral : public Token {
    public:
        TFloatLiteral(SourceChar start, std::string strFloat) : Token(tFloatLiteral, start), strFloat(strFloat) {};
        virtual std::string getInCodeIdentificationString() {
            return strFloat + Token::getInCodeIdentificationString();
        }


	std::string zitherLiteralRepresentation() {
	    return strFloat;
	}
        
        std::string strFloat;
    };*/
    
}

#endif /* TFloatLiteral_hpp */
