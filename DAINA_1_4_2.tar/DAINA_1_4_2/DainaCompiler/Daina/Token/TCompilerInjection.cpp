//
//  TCompilerInjection.cpp
//  DainaCompiler
//
//  Created by SamWit on 15/05/2017.
//  Copyright © 2017 Samuel Whitton. All rights reserved.
//

#include "TCompilerInjection.hpp"
