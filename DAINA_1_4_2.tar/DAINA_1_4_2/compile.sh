#!/bin/bash

make clean;
make daina;