//
//  TNaturalLiteral.cpp
//  DainaCompiler
//
//  Created by SamWit on 27/05/2016.
//  Copyright © 2018 Samuel Whitton. All rights reserved.
//

#include "TNaturalLiteral.hpp"
